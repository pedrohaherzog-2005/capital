package grafos;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.List;

public class Main {
    private static List<Point> coordenadasCapitais;
    private static List<Integer> caminhoAtual;

    public static void main(String[] args) {
        inicializarCoordenadas();

        JFrame frame = new JFrame("Rotas no Mapa do Brasil");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 800);
        frame.setMinimumSize(new Dimension(800, 600));
        frame.setLocationRelativeTo(null);

        JPanel painelPrincipal = new JPanel(new BorderLayout(10, 10));
        painelPrincipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel painelEntrada = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel label1 = new JLabel("Origem:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        painelEntrada.add(label1, gbc);

        JTextField origem = new JTextField(10);
        gbc.gridx = 1;
        gbc.gridy = 0;
        painelEntrada.add(origem, gbc);

        JLabel label2 = new JLabel("Destino:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        painelEntrada.add(label2, gbc);

        JTextField destino = new JTextField(10);
        gbc.gridx = 1;
        gbc.gridy = 1;
        painelEntrada.add(destino, gbc);

        JButton btnCalcular = new JButton("Calcular Menor Rota");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        painelEntrada.add(btnCalcular, gbc);

        String[] siglasCapitais = {
                "1: SE", "2: PA", "3: MG", "4: RR", "5: DF", "6: MS", "7: MT",
                "8: PR", "9: SC", "10: CE", "11: GO", "12: PB", "13: AP", "14: AL",
                "15: AM", "16: RN", "17: TO", "18: RS", "19: RO", "20: PE", "21: AC",
                "22: RJ", "23: BA", "24: MA", "25: SP", "26: PI", "27: ES"
        };

        StringBuilder lista = new StringBuilder();
        for (String sigla : siglasCapitais) {
            lista.append(sigla).append("\n");
        }

        JTextArea areaLista = new JTextArea(lista.toString());
        areaLista.setEditable(false);
        JScrollPane scroll = new JScrollPane(areaLista);
        scroll.setPreferredSize(new Dimension(120, 500));

        JPanel painelCentral = new JPanel(new BorderLayout(10, 10));

        MapaPainel mapaPainel = new MapaPainel();
        mapaPainel.setPreferredSize(new Dimension(600, 500));
        painelCentral.add(mapaPainel, BorderLayout.NORTH);

        JTextArea areaResultado = new JTextArea();
        areaResultado.setEditable(false);
        areaResultado.setBorder(BorderFactory.createTitledBorder("Menor Rota"));
        JScrollPane scrollResultado = new JScrollPane(areaResultado);
        scrollResultado.setPreferredSize(new Dimension(600, 100));
        painelCentral.add(scrollResultado, BorderLayout.CENTER);

        painelPrincipal.add(painelEntrada, BorderLayout.WEST);
        painelPrincipal.add(scroll, BorderLayout.EAST);
        painelPrincipal.add(painelCentral, BorderLayout.CENTER);

        frame.add(painelPrincipal);

        Rotas rotas = new Rotas();

        btnCalcular.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int origemIdx = Integer.parseInt(origem.getText().replaceAll("[^0-9]", "")) - 1;
                    int destinoIdx = Integer.parseInt(destino.getText().replaceAll("[^0-9]", "")) - 1;
                    if (origemIdx < 0 || origemIdx >= 27 || destinoIdx < 0 || destinoIdx >= 27) {
                        areaResultado.setText("Informe números válidos para origem e destino.");
                        caminhoAtual = null;
                        mapaPainel.repaint();
                        return;
                    }
                    Rotas.ResultadoDijkstra resultado = rotas.dijkstra(origemIdx, destinoIdx, siglasCapitais);
                    areaResultado.setText(resultado.caminho + "\nDistância total: " + resultado.distancia + " km");
                    caminhoAtual = resultado.caminhoIndices;
                    mapaPainel.repaint();
                } catch (Exception ex) {
                    areaResultado.setText("Erro: informe o número da sigla de origem e destino.");
                    caminhoAtual = null;
                    mapaPainel.repaint();
                }
            }
        });

        frame.setVisible(true);
    }

    static class MapaPainel extends JPanel {
        private ImageIcon icon;

        public MapaPainel() {
            icon = new ImageIcon(Main.class.getResource("./images/mapa_do_brasil.jpeg"));
            if (icon.getImageLoadStatus() != MediaTracker.COMPLETE) {
                System.err.println("Erro ao carregar a imagem!");
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            if (icon.getImageLoadStatus() == MediaTracker.COMPLETE) {
                Image img = icon.getImage();
                g2d.drawImage(img, 0, 0, getWidth(), getHeight(), this);
            } else {
                g2d.setColor(Color.RED);
                g2d.drawString("Imagem não carregada", 10, 20);
            }

            g2d.setColor(Color.WHITE);
            for (Point p : coordenadasCapitais) {
                int x = (int) (p.x * getWidth() / 600.0);
                int y = (int) (p.y * getHeight() / 500.0);
                g2d.fillOval(x - 5, y - 5, 10, 10);
            }

            if (caminhoAtual != null && caminhoAtual.size() > 1) {
                g2d.setColor(Color.BLACK);
                g2d.setStroke(new BasicStroke(2));
                for (int i = 0; i < caminhoAtual.size() - 1; i++) {
                    Point p1 = coordenadasCapitais.get(caminhoAtual.get(i));
                    Point p2 = coordenadasCapitais.get(caminhoAtual.get(i + 1));
                    int x1 = (int) (p1.x * getWidth() / 600.0);
                    int y1 = (int) (p1.y * getHeight() / 500.0);
                    int x2 = (int) (p2.x * getWidth() / 600.0);
                    int y2 = (int) (p2.y * getHeight() / 500.0);
                    g2d.drawLine(x1, y1, x2, y2);
                }
            }
        }
    }

    private static void inicializarCoordenadas() {
        coordenadasCapitais = new ArrayList<>();
        coordenadasCapitais.add(new Point(550, 210)); // SE
        coordenadasCapitais.add(new Point(315, 145)); // PA
        coordenadasCapitais.add(new Point(440, 300)); // MG
        coordenadasCapitais.add(new Point(200, 60)); // RR
        coordenadasCapitais.add(new Point(395, 270)); // DF
        coordenadasCapitais.add(new Point(300, 320)); // MS
        coordenadasCapitais.add(new Point(270, 220)); // MT
        coordenadasCapitais.add(new Point(350, 380)); // PR
        coordenadasCapitais.add(new Point(360, 420)); // SC
        coordenadasCapitais.add(new Point(515, 150)); // CE
        coordenadasCapitais.add(new Point(360, 270)); // GO
        coordenadasCapitais.add(new Point(580, 170)); // PB
        coordenadasCapitais.add(new Point(350, 50)); // AP
        coordenadasCapitais.add(new Point(570, 205)); // AL
        coordenadasCapitais.add(new Point(160, 115)); // AM
        coordenadasCapitais.add(new Point(560, 150)); // RN
        coordenadasCapitais.add(new Point(380, 200)); // TO
        coordenadasCapitais.add(new Point(320, 450)); // RS
        coordenadasCapitais.add(new Point(180, 200)); // RO
        coordenadasCapitais.add(new Point(540, 185)); // PE
        coordenadasCapitais.add(new Point(80, 200)); // AC
        coordenadasCapitais.add(new Point(460, 360)); // RJ
        coordenadasCapitais.add(new Point(480, 240)); // BA
        coordenadasCapitais.add(new Point(420, 130)); // MA
        coordenadasCapitais.add(new Point(380, 360)); // SP
        coordenadasCapitais.add(new Point(485, 170)); // PI
        coordenadasCapitais.add(new Point(495, 320)); // ES
    }

    public static class Rotas {
        private int[][] grafo;
        private int numVertices = 27;

        public Rotas() {
            grafo = new int[numVertices][numVertices];

            // Norte
            adicionarRota(12, 1, 837); // AP - PA
            adicionarRota(1, 23, 806); // PA - MA
            adicionarRota(1, 16, 1130); // PA - TO
            adicionarRota(14, 3, 785); // AM - RR
            adicionarRota(14, 18, 901); // AM - RO
            adicionarRota(18, 20, 544); // RO - AC

            // Nordeste
            adicionarRota(23, 25, 446); // MA - PI
            adicionarRota(25, 9, 634); // PI - CE
            adicionarRota(9, 15, 534); // CE - RN
            adicionarRota(9, 11, 688); // CE - PB
            adicionarRota(15, 11, 185); // RN - PB
            adicionarRota(11, 19, 120); // PB - PE
            adicionarRota(19, 13, 117); // PE - AL
            adicionarRota(13, 0, 294); // AL - SE
            adicionarRota(0, 22, 356); // SE - BA
            adicionarRota(22, 25, 1162); // BA - PI

            // Centro-Oeste
            adicionarRota(4, 10, 209); // DF - GO
            adicionarRota(10, 16, 873); // GO - TO
            adicionarRota(10, 6, 937); // GO - MT
            adicionarRota(10, 5, 900); // GO - MS
            adicionarRota(5, 6, 694); // MS - MT
            adicionarRota(6, 18, 1457); // MT - RO

            // Sudeste
            adicionarRota(2, 4, 741); // MG - DF
            adicionarRota(2, 10, 906); // MG - GO
            adicionarRota(2, 24, 586); // MG - SP
            adicionarRota(2, 26, 524); // MG - ES
            adicionarRota(2, 21, 434); // MG - RJ
            adicionarRota(24, 21, 429); // SP - RJ
            adicionarRota(24, 7, 540); // SP - PR
            adicionarRota(26, 21, 521); // ES - RJ
            adicionarRota(22, 2, 1377); // BA - MG

            // Sul
            adicionarRota(7, 8, 300); // PR - SC
            adicionarRota(8, 17, 476); // SC - RS
            adicionarRota(5, 7, 991); // MS - PR

            // Ligações Nordeste/Centro-Oeste
            adicionarRota(16, 25, 1112); // TO - PI
            adicionarRota(22, 4, 1350); // BA - DF

            // Ligações Nordeste/Sudeste
            adicionarRota(22, 24, 1962); // BA - SP
        }

        public void adicionarRota(int origem, int destino, int peso) {
            grafo[origem][destino] = peso;
            grafo[destino][origem] = peso;
        }

        public ResultadoDijkstra dijkstra(int origem, int destino, String[] siglas) {
            int[] dist = new int[numVertices];
            boolean[] visitado = new boolean[numVertices];
            int[] anterior = new int[numVertices];
            Arrays.fill(dist, Integer.MAX_VALUE);
            Arrays.fill(anterior, -1);
            dist[origem] = 0;

            for (int i = 0; i < numVertices; i++) {
                int u = -1;
                for (int j = 0; j < numVertices; j++) {
                    if (!visitado[j] && (u == -1 || dist[j] < dist[u])) {
                        u = j;
                    }
                }
                if (dist[u] == Integer.MAX_VALUE)
                    break;
                visitado[u] = true;
                for (int v = 0; v < numVertices; v++) {
                    if (grafo[u][v] > 0 && dist[u] + grafo[u][v] < dist[v]) {
                        dist[v] = dist[u] + grafo[u][v];
                        anterior[v] = u;
                    }
                }
            }

            List<Integer> caminho = new ArrayList<>();
            for (int at = destino; at != -1; at = anterior[at]) {
                caminho.add(at);
            }
            Collections.reverse(caminho);

            StringBuilder caminhoStr = new StringBuilder("Caminho: ");
            for (int idx = 0; idx < caminho.size(); idx++) {
                caminhoStr.append(siglas[caminho.get(idx)]);
                if (idx < caminho.size() - 1)
                    caminhoStr.append(" -> ");
            }

            return new ResultadoDijkstra(caminhoStr.toString(), dist[destino], caminho);
        }

        public static class ResultadoDijkstra {
            public String caminho;
            public int distancia;
            public List<Integer> caminhoIndices;

            public ResultadoDijkstra(String caminho, int distancia, List<Integer> caminhoIndices) {
                this.caminho = caminho;
                this.distancia = distancia;
                this.caminhoIndices = caminhoIndices;
            }
        }
    }
}